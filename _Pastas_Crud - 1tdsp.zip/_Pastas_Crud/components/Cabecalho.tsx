import Menu from './Menu'

export default function Cabecalho(){
    return(
        <header>
            <h1>FIAP - Eletro</h1>
             <Menu/>
        </header>
    )
}

