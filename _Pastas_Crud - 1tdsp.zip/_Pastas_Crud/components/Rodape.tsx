export default function Rodape(){

    return(
        <footer>
            <p>Av. Paulista, 1060 - Bela Vista - Sáo Paulo - SP</p>
        </footer>
    )
}

