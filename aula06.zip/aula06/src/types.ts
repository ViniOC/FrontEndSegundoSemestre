export type itemProduto = {
    id: number;
    nome: string;
    preco: number;
}