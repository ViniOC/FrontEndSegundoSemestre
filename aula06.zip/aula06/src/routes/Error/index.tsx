export default function Error() {

    return (
        <main>
            <h1>Error</h1>
        </main>
    )
    


}